% esta entrada corresponde al primer ejemplo en el enunciado
size(9).
%  color   init  fin
c(blue,    9,1,  2,2).
c(brown,   3,1,  8,4).
c(red,     3,4,  1,7).
c(cyan,    1,8,  4,4).
c(green,   1,9,  5,2).
c(yellow,  7,7,  7,9).
c(pink,    6,5,  8,7).
c(violet,  8,9,  9,6).
c(orange,  5,8,  8,8).

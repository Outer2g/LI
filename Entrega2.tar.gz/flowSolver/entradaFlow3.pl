% esta entrada corresponde al primer ejemplo en el enunciado
size(3).
%  color   init  fin
c(blue,    1,1,  2,2).
c(brown,   3,1,  1,2). 
